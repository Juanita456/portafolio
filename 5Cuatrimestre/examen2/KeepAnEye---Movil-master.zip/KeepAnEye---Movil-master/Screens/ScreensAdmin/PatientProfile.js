// PatientProfile.js

import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, Button, TouchableOpacity } from 'react-native';;


const PatientProfile = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text>Bienvenido al perfil de tus pacientes!</Text>
    
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default PatientProfile;
