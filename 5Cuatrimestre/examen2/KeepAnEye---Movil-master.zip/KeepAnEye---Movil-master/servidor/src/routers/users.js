const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const userSchema = require('../models/usersAdmin');

const router = express.Router();
// Secret key for JWT
const JWT_SECRET = "jq93hfcniw";

// Register user
router.post('/register', async (req, res) => {
    const { email, password } = req.body;

    try {
        // Check if user already exists
        const existingUser = await userSchema.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "User already exists" });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create new user
        const newUser = new userSchema({ email, password: hashedPassword });
        const savedUser = await newUser.save();

        res.json(savedUser);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.post('/login', async (req, res) => {
    const { first_name, password, user_type } = req.body;
    try {
        // Buscar al usuario por su nombre
        const user = await userSchema.findOne({ "name.first_name": first_name, "password":password });
        if (!user) {
            return res.status(400).json({ message: "Usuario no encontrado" });
        }
        // Comparar contraseñas
        //   const isMatch = await bcrypt.compare(password, user.password);
        //   if (!isMatch) {
        //       return res.status(400).json({ message: "Credenciales incorrectas" });
        //  }

        // Generar JWT
        const token = jwt.sign({ _id: user._id, user_type: user.user_type }, JWT_SECRET, { expiresIn: '1h' });

        res.json({ token, user_type: user.user_type,  _id: user._id});
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Middleware to authenticate token
const authenticateToken = (req, res, next) => {
    const token = req.header('Authorization');
    if (!token) return res.status(401).json({ message: "Access denied" });

    try {
        const verified = jwt.verify(token, JWT_SECRET);
        req.user = verified;
        next();
    } catch (error) {
        res.status(400).json({ message: "Invalid token" });
    }
};

//update a user
router.put("/UpdateAdmin/:id", (req, res) => {
     const { id } = req.params;
     const { patient_id, relationship } = req.body;
     userSchema
       .updateOne({ _id: id }, { $push: {patients:  { patient_id, relationship } }})
       .then((data) => res.json(data))
       .catch((error) => res.json({ message: error }));
   });

// Protected route example
router.get('/protected', authenticateToken, (req, res) => {
    res.json({ message: "This is a protected route" });
});
// create user
// router.post('/users', (req, res) => {
//     const users = userSchema(req.body);
//     users.save().then((data) => res.json(data))
//     .catch((error) => res.json({ message: error }))
//     // res.send("create user");
// })

// //get all users
// router.get('/users', (req, res) => {
//     userSchema
//     .find().then((data) => res.json(data))
//     .catch((error) => res.json({ message: error }))
//     // res.send("create user");
// })

// //get a user
// router.get('/users/:id', (req, res) => {
//     const { id } = req.params;
//     userSchema
//     .findById(id).then((data) => res.json(data))
//     .catch((error) => res.json({ message: error }))
//     // res.send("create user");
// })

// //update a user
// router.put('/users/:id', (req, res) => {
//     const { id } = req.params;
//     const updateData = req.body;
   
//     userSchema.findByIdAndUpdate(id, updateData, { new: true, runValidators: true })
//         .then((data) => {
//             if (!data) {
//                 return res.status(404).json({ message: 'User not found' });
//             }
//             res.json(data);
//         })
//         .catch((error) => res.status(400).json({ message: error.message }));
// })


// // delete a user
// router.delete("/users/:id", (req, res) => {
//     const { id } = req.params;
//     userSchema
//       .deleteOne({ _id: id })
//       .then((data) => res.json(data))
//       .catch((error) => res.json({ message: error }));
//   });

//  update a user
// router.put("/users/:id", (req, res) => {
//     const { id } = req.params;
//     const { name, age, email } = req.body;
//     userSchema
//       .updateOne({ _id: id }, { $set: { name, age, email } })
//       .then((data) => res.json(data))
//       .catch((error) => res.json({ message: error }));
//   });

module.exports = router;