const express = require('express');
const mongoose = require('mongoose');
require("dotenv").config();
const userRoutes = require("./routers/users");
const patientRoutes = require("./routers/patient");

const app = express();
const port = process.env.PORT || 9000;

// middleware
app.use(express.json());
app.use('/', userRoutes);
app.use('/patients', patientRoutes);

// routes
app.get('/', (req, res) => {
    res.send('Welcome to my API');
});

// mongodb connection
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('Connected to MongoDB Atlas'))
    .catch((error) => console.error(error));

app.listen(port, () => console.log('Server listening on port', port));
