const mongoose = require('mongoose');
const { Schema } = mongoose;

const userSchema = new Schema({
    name: {
        first_name: { type: String, required: true },
        last_name: { type: String, required: true }
    },
    sex: { type: String, required: true },
    user_photo: { type: String, required: false },
    born_date: { type: Date, required: true },
    user_type: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    phone: { type: String, required: true },
    address: {
        street: { type: String, required: true },
        city: { type: String, required: true },
        state: { type: String, required: true },
        zip: { type: String, required: true }
    },
    created_at: { type: Date, default: Date.now },
    status: { type: String, required: true },
    subscription: {
        status: { type: String, required: true },
        start_date: { type: Date, required: true },
        end_date: { type: Date, required: true }
    },
    patients: [
        {
            patient_id: { type: Schema.Types.ObjectId, ref: 'Patient', required: true },
            relationship: { type: String, required: true }
        }
    ]
});

module.exports = mongoose.model('User', userSchema);