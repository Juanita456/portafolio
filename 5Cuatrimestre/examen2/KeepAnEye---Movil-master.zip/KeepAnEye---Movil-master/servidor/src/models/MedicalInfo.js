const mongoose = require('mongoose');
const {Schema }  = mongoose;

const PatientMedical = new Schema({
        patient_id: { type: String, required: true },
        health_info: {
            medicines: [
                {
                    name: { type: String, required: true },
                    dosage: { type: String, required: true },
                    frequency: { type: String, required: true }
                }
            ],
            allergies: [
                {
                    name: { type: String, required: false },
                    severity: { type: String, required: false },
                    reaction: { type: String, required: false },
                    treatment: { type: String, required: false }
                }
            ],
            medical_conditions: [
                {
                    name: { type: String, required: true },
                severity: { type: String, required: true },
                    treatment: { type: String, required: true },
                    symptoms: { type: String, required: true },
                    diagnosis_date: { type: String, required: true }
                }
            ]
        },
        NSS: { type: String, required: true },
        blood_type: { type: String, required: true },
        height: Str,
        weight: "String",
        hospitals: [
            {
                name: { type: String, required: true },
                phone: { type: String, required: true },
                address: {
                    street: { type: String, required: true },
                    city: { type: String, required: true },
                    ate: { type: String, required: true },
                    zip: { type: String, required: true }
                }
            }
        ],
        medical_documents: [
            {
                name: { type: String, required: true },
                type: { type: String, required: true },
                date: { type: Date, required: true },
                url: { type: String, required: true }
            }
        ]

});


module.exports = mongoose.model('PatientMedical', PatientMedica);
