const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { Patient, PatientMedical, PatientContact } = require('../models/userPatient'); // Adjust the import based on your folder structure

// const PatientMedical = require('../models/MedicalInfo');

const router = express.Router();
// Secret key for JWT
const JWT_SECRET = "jq93hfcniw";

//registrar usuario de tipo patient
router.post('/registerPatient', async (req, res) => {
   try {
     const patient = new Patient(req.body);
     const savedPatient = await patient.save();
 
     // Devuelve el ID del paciente en la respuesta JSON junto con un mensaje de éxito
     res.status(200).json({
       _id: savedPatient._id,
       message: 'Paciente registrado exitosamente',
     });
   } catch (error) {
     // Si ocurre algún error durante el guardado, maneja el error y devuelve un mensaje de error
     console.error(error);
     res.status(500).json({ message: 'Error al registrar el paciente' });
   }
 });
 


// Route to register medical info
router.post('/registerMedicalInfo',(req, res) => {
   const medicalInfo = PatientMedical(req.body);
   medicalInfo.save().then((data) => res.json(data))
   .catch((error) => res.json({ message: error }))
   // res.send("create user");
});

router.post('/registerContact',(req, res) => {
   const contact = PatientContact(req.body);
     contact.save().then((data) => res.json(data))
     .catch((error) => res.json({ message: error }))
     // res.send("create user");
});

module.exports = router;