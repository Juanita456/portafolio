import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import PatientInfo from './PatientInfo';
import ReviewScreen from './ReviewScreen';
import MedicalInfo from './MedicalInfo';
import EmergencyContact from './EmergencyContact';
import HomeScreen from '../HomeScreen';

const Stack = createStackNavigator();

const PatientRegistration = ({ navigation, route }) => {
  const { _id } = route.params;
  return (
    <Stack.Navigator initialRouteName="PersonalInfo">
      <Stack.Screen name="PersonalInfo" component={PatientInfo} options={{ headerShown: false }}  initialParams={{ _id }}/>
      <Stack.Screen name="EmergencyContact" component={EmergencyContact} options={{ headerShown: false }} />
      <Stack.Screen name="MedicalInfo" component={MedicalInfo} options={{ headerShown: false }} />
      <Stack.Screen name="HomeScreen" component={HomeScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Registro Pacientes" component={PatientRegistration} options={{ headerShown: false }} />
    </Stack.Navigator>
  );
};

export default PatientRegistration;
