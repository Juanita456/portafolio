// HomeScreen.js

import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, Button, TouchableOpacity } from 'react-native';
import * as SecureStore from 'expo-secure-store';

const KEY_ON_STORAGE = "KEY_ON_STORAGE";

const HomeScreen = ({ navigation, route }) => {
  const { _id } = route.params;
  const [token, setToken] = useState(null);

  useEffect(() => {
    const fetchToken = async () => {
      const storedToken = await SecureStore.getItemAsync(KEY_ON_STORAGE);
      if (!storedToken) {
        navigation.replace('Login');
      } else {
        setToken(storedToken);
      }
    };
    fetchToken();
  }, []);

  const handleLogoutPress = async () => {
    await SecureStore.deleteItemAsync(KEY_ON_STORAGE);
    navigation.replace('Login');
  };

  return (
    <View style={styles.container}>
      <Text>Bienvenido KeepAnEye!</Text>
      <TouchableOpacity style={styles.button} onPress={handleLogoutPress}>
        <Text style={styles.buttonText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  button: {
    backgroundColor: '#007C71',
    marginTop: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    width: '40%', // Ancho del botón al 80% del contenedor
    height: '',
  alignItems: 'center', // Alinear el contenido al centro horizontalmente
    borderRadius: 8,
  },
  buttonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
});

export default HomeScreen;
