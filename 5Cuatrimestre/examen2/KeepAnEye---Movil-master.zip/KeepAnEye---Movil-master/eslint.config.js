const config = {
  parserOptions: {
    ecmaVersion: 2021,
    sourceType: 'module',
    ecmaFeatures: {
      jsx: true,
    },
  },
  env: {
    browser: true,
    node: true,
    es6: true,
  },
  plugins: ['react', 'react-hooks'],
  rules: {
    // Include rules from eslint:recommended
    'no-console': 'warn',
    // Include rules from plugin:react/recommended
    'react/prop-types': 'off',
    'react/react-in-jsx-scope': 'off',
    // Include rules from plugin:react-hooks/recommended
    'react-hooks/rules-of-hooks': 'error',
    'react-hooks/exhaustive-deps': 'warn',
    // Include rules from prettier
    // Add your prettier rules here
  },
};

module.exports = config;
