const mongoose = require('mongoose');
const { Schema } = mongoose;

const PatientMedicalSchema = new Schema({
    patient_id: { type: String, required: true },
    health_info: {
        medicines: [
            {
                name: { type: String, required: true },
                dosage: { type: String, required: true },
                frequency: { type: String, required: true }
            }
        ],
        allergies: [
            {
                name: { type: String, required: false },
                severity: { type: String, required: false },
                reaction: { type: String, required: false },
                treatment: { type: String, required: false }
            }
        ],
        medical_conditions: [
            {
                name: { type: String, required: true },
                severity: { type: String, required: true },
                treatment: { type: String, required: true },
                symptoms: { type: String, required: true },
                diagnosis_date: { type: String, required: true }
            }
        ]
    },
    NSS: { type: String, required: true },
    blood_type: { type: String, required: true },
    height: String,
    weight: String,
    hospitals: [
        {
            name: { type: String, required: true },
            phone: { type: String, required: true },
            address: {
                street: { type: String, required: true },
                city: { type: String, required: true },
                state: { type: String, required: true },
                zip: { type: String, required: true }
            }
        }
    ],
    medical_documents:[
        {
            mimeType: { type: String, required: true },
            name: { type: String, required: true },
            date: { type: Date, required: true },
            uri: { type: String, required: true }
        }
    ]
});

const PatientSchema = new Schema({
    name: {
        first_name: { type: String, required: true },
        last_name: { type: String, required: true } 
    },
    sex: { type: String, required: true },
    user_photo: { type: String, required: false },
    born_date: { type: Date, required: true },
    user_type: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    phone: { type: String, required: true },
    address: {
        street: { type: String, required: true },
        city: { type: String, required: true },
        state: { type: String, required: true },
        zip: { type: String, required: true }
    },
    created_at: { type: Date, default: Date.now },
    status: { type: String, required: true },
});

const PatientContact = new Schema({

        patient_id: { type: String, required: true },
        emergency_contacts: [
            {
                name: { type: String, required: true },
                relationship: { type: String, required: true },
                contactInformation: {
                    phone: { type: String, required: true },
                    email: { type: String, required: true },
                },
                notifications: [
                    {
                        type: { type: String, required: true },
                        status: { type: String, required: true },
                    }
                ]
            }
        ]
    
});

module.exports = {
    Patient: mongoose.model('users', PatientSchema, 'users'),
    PatientMedical: mongoose.model('MedicalInfo', PatientMedicalSchema, 'medicalInfo'),
    PatientContact: mongoose.model('EmergencieContacts', PatientContact, 'emergencieContacts')
};
