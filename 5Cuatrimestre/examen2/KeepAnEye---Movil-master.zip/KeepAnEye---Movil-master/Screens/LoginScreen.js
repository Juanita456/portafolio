import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, TextInput, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as SecureStore from 'expo-secure-store';
import { API_URL } from '../Puerto';
const KEY_ON_STORAGE = "KEY_ON_STORAGE";

const LoginScreen = ({ navigation, route }) => {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);

  const handleLoginPress = async () => {
    try {
      const response = await fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ first_name: name, password: password }),
      });
      const data = await response.json();
      if (response.ok) {
        await SecureStore.setItemAsync(KEY_ON_STORAGE, data.token);
        navigation.replace('Drawer', { user_type: data.user_type, _id: data._id }); // Pass user_type here
      } else {
        alert("Error en el login: " + data.message);
      }
    } catch (error) {
      console.error(error);
      alert("Error en el login");
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image source={require('../assets/images.png')} style={styles.logo} />
        <Text style={styles.title}>KeepAnEye</Text>
      </View>
      <View style={styles.formContainer}>
        <Text style={styles.inputLabel}>Nombre</Text>
        <TextInput
          style={styles.input}
          value={name}
          onChangeText={setName}
        />
        <Text style={styles.inputLabel}>Contraseña</Text>
        <View style={styles.passwordContainer}>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            secureTextEntry={!passwordVisible}
          />
          <TouchableOpacity
            style={styles.eyeIcon}
            onPress={() => setPasswordVisible(!passwordVisible)}
          >
            <Ionicons name={passwordVisible ? 'eye' : 'eye-off'} size={24} color="black" />
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={styles.loginButton} onPress={handleLoginPress}>
          <Text style={styles.buttonText}>Entrar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffff',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logo: {
    width: 100,
    height: 100,
    marginBottom: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333333',
  },
  formContainer: {
    width: '100%',
    alignItems: 'center',
  },
  inputLabel: {
    color: '#333333',
    fontSize: 16,
    marginBottom: 4,
    alignSelf: 'flex-start',
  },
  input: {
    height: 50,
    width: '100%',
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: '#333333',
    borderRadius: 8,
    color: '#333333',
    marginBottom: 12,
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
  },
  eyeIcon: {
    position: 'absolute',
    right: 16,
  },
  loginButton: {
    backgroundColor: '#007C71',
    paddingVertical: 12,
    paddingHorizontal: 60,
    borderRadius: 25,
    alignItems: 'center',
  },
  buttonText: {
    color: '#E9E9F2',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default LoginScreen;
