import React, { useState } from 'react';
import { StyleSheet, Text, View, TextInput, ScrollView, TouchableOpacity, ActivityIndicator, Alert  } from 'react-native';
import { API_URL } from '../../Puerto';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import DropdownSelect from 'react-native-input-select';
import Icon from 'react-native-vector-icons/MaterialIcons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { FontAwesome5 } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';

const MedicalInfo = ({ navigation, route }) => {
  const { control, handleSubmit, formState: { errors } } = useForm();
  const [showDatePicker, setShowDatePicker] = useState(false); 
  const [date, setDate] = useState(new Date());
  const [uploading, setUploading] = useState(false);
  const [documents, setDocuments] = useState([]);
  
  const patientId = route.params?.patientId;


  const { fields: medicineFields, append: appendMedicine, remove: removeMedicine } = useFieldArray({
    control,
    name: 'health_info.medicines'
  });

  const { fields: allergyFields, append: appendAllergy, remove: removeAllergy } = useFieldArray({
    control,
    name: 'health_info.allergies'
  });

  const { fields: conditionFields, append: appendCondition, remove: removeCondition } = useFieldArray({
    control,
    name: 'health_info.medical_conditions'
  });

  const { fields: hospitalFields, append: appendHospital, remove: removeHospital } = useFieldArray({
    control,
    name: 'hospitals'
  });

  const { append: appendDocument } = useFieldArray({
    control,
    name: 'medical_documents'
  });
  const removeDocument = (index) => {
    const updatedDocuments = [...documents];
    updatedDocuments.splice(index, 1);
    setDocuments(updatedDocuments);
  };

  const pickDocument = async () => {

    let document = await DocumentPicker.getDocumentAsync({});
    if (!document.canceled) {
      if(document.assets[0].mimeType == 'application/pdf'){
      const newDocument = {
        mimeType: document.assets[0].mimeType,
        name: document.assets[0].name,
        date: new Date().toISOString(), // Puedes usar new Date() para la fecha actual
        uri: document.assets[0].uri,
      };
      setDocuments([...documents, newDocument]);
    }else{
      alert('Formato incorrecto solo PDF');
    }
    } else {
      alert('No se seleccionó ningún documento');
    }
  };
  const onSubmit = async (data) => {
    console.log('Data to submit:', data);
    setUploading(true);

    // Submit Medical Info
    const medicalResponse = await fetch(`${API_URL}/patients/registerMedicalInfo`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        patient_id: patientId, // Link to the patient
        NSS: data.NSS,
        blood_type: data.blood_type,
        height: data.height,
        weight: data.weight,
        health_info: {
          medicines: data.health_info.medicines.map(medicine => ({
            name: medicine.name,
            dosage: medicine.dosage,
            frequency: medicine.frequency,
          })),
          allergies: data.health_info.allergies.map(allergy => ({
            name: allergy.name,
            severity: allergy.severity,
            reaction: allergy.reaction,
            treatment: allergy.treatment,
          })),
          medical_conditions: data.health_info.medical_conditions.map(condition => ({
            name: condition.name,
            severity: condition.severity,
            treatment: condition.treatment,
            symptoms: condition.symptoms,
            diagnosis_date: condition.diagnosis_date,
          })),
        },
        hospitals: data.hospitals.map(hospital => ({
          name: hospital.name,
          phone: hospital.phone,
          address: {
            street: hospital.street,
            city: hospital.city,
            state: hospital.state,
            zip: hospital.zip,
          },
        })),
        medical_documents: documents,
      }),
    });
    navigation.navigate('EmergencyContact', { patientId});
  };

  return (
    <View style={styles.container}>
      <ScrollView>
        <Text style={styles.title}>Información Médica</Text>
        
        {/* NSS */}
        <Controller
          control={control}
          name="NSS"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="NSS"
              keyboardType='numeric'
              value={value}
              onChangeText={onChange}
              style={styles.input}
            />
          )}
           rules={{ required: 'NSS requerido' }}
        defaultValue=""
        />
        {errors.NSS && <Text style={styles.error}>{errors.NSS.message}</Text>}
        
         {/* Tipo de Sangre */}
      <Controller
        control={control}
        name="blood_type"
        render={({ field: { onChange, value } }) => (
          <DropdownSelect
            placeholder="Tipo de Sangre"
            options={[
              { name: 'A+', id: 'A+' },
              { name: 'A-', id: 'A-' },
              { name: 'B+', id: 'B+' },
              { name: 'B-', id: 'B-' },
              { name: 'AB+', id: 'AB+' },
              { name: 'AB-', id: 'AB-' },
              { name: 'O+', id: 'O+' },
              { name: 'O-', id: 'O-' },
            ]}
            optionLabel="name"
            optionValue="id"
            selectedValue={value}
            onValueChange={(itemValue) => {
              onChange(itemValue);
            }}
            containerStyle={styles.dropdownContainer}
            selectStyle={styles.dropdownSelect}
            optionTextStyle={styles.dropdownOptionText}
            dropdownStyle={styles.dropdown}
          />
        )}
        rules={{ required: 'Tipo de Sangre es requerido' }}
        defaultValue=""
      />
      {errors.blood_type && <Text style={styles.error}>{errors.blood_type.message}</Text>}
        
        {/* Height */}
        <Controller
          control={control}
          name="height"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Altura"
              keyboardType='numeric'
              value={value}
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{ required: 'Altura es requerido' }}
        defaultValue=""
        />
        {errors.height && <Text style={styles.error}>{errors.height.message}</Text>}
        
        {/* Weight */}
        <Controller
          control={control}
          name="weight"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Peso"
              value={value}
              keyboardType='numeric'
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{ required: 'Peso es requerido' }}
        defaultValue=""
        />
        {errors.weight && <Text style={styles.error}>{errors.weight.message}</Text>}
        
        {/* Medicines Section */}
        <Text style={styles.subtitle}>Medicinas</Text>
        {medicineFields.map((item, index) => (
          <View key={item.id} style={styles.sectionContainer}>
            <Controller
              control={control}
              name={`health_info.medicines[${index}].name`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Nombre de la Medicina"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.health_info?.medicines?.[index]?.name && <Text style={styles.error}>{errors.health_info?.medicines[index].name.message}</Text>}

            <Controller
              control={control}
              name={`health_info.medicines[${index}].dosage`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Dosis"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.health_info?.medicines?.[index]?.dosage && <Text style={styles.error}>{errors.health_info?.medicines[index].dosage.message}</Text>}
            <Controller
              control={control}
              name={`health_info.medicines[${index}].frequency`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Frecuencia"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.health_info?.medicines?.[index]?.frequency && <Text style={styles.error}>{errors.health_info?.medicines[index].frequency.message}</Text>}
            <TouchableOpacity style={styles.removeButton} onPress={() => removeMedicine(index)}>
              <Icon name="delete" size={30} color="#A60010" />
            </TouchableOpacity>
          </View>
        ))}
        <TouchableOpacity style={styles.buttonAñadir} onPress={() => appendMedicine({ name: '', dosage: '', frequency: '' })}>
          <Text style={styles.buttonText}>Añadir Medicina</Text>
        </TouchableOpacity>
        
        {/* Allergies Section */}
        <Text style={styles.subtitle}>Alergias</Text>
        {allergyFields.map((item, index) => (
          <View key={item.id} style={styles.sectionContainer}>
            <Controller
              control={control}
              name={`health_info.allergies[${index}].name`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Nombre de la Alergia"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
            />
           
            <Controller
              control={control}
              name={`health_info.allergies[${index}].severity`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Severidad"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
            />
          
            <Controller
              control={control}
              name={`health_info.allergies[${index}].reaction`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Reacción"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
            />
           
            <Controller
              control={control}
              name={`health_info.allergies[${index}].treatment`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Tratamiento"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
            />
            <TouchableOpacity style={styles.removeButton} onPress={() => removeAllergy(index)}>
              <Icon name="delete" size={30} color="#A60010" />
            </TouchableOpacity>
          </View>
        ))}
        <TouchableOpacity style={styles.buttonAñadir} onPress={() => appendAllergy({ name: '', severity: '', reaction: '', treatment: '' })}>
          <Text style={styles.buttonText}>Añadir Alergia</Text>
        </TouchableOpacity>
        
        {/* Medical Conditions Section */}
        <Text style={styles.subtitle}>Condiciones Médicas</Text>
        {conditionFields.map((item, index) => (
          <View key={item.id} style={styles.sectionContainer}>
            <Controller
              control={control}
              name={`health_info.medical_conditions[${index}].name`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Nombre de la Condición"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.health_info?.medical_conditions?.[index]?.name && <Text style={styles.error}>{errors.health_info?.medical_conditions[index].name.message}</Text>}
            
            <Controller
              control={control}
              name={`health_info.medical_conditions[${index}].severity`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Severidad"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.health_info?.medical_conditions?.[index]?.severity && <Text style={styles.error}>{errors.health_info?.medical_conditions[index].severity.message}</Text>}
            
            <Controller
              control={control}
              name={`health_info.medical_conditions[${index}].treatment`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Tratamiento"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.health_info?.medical_conditions?.[index]?.treatment && <Text style={styles.error}>{errors.health_info?.medical_conditions[index].treatment.message}</Text>}
            
            <Controller
              control={control}
              name={`health_info.medical_conditions[${index}].symptoms`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Síntomas"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.health_info?.medical_conditions?.[index]?.symptoms && <Text style={styles.error}>{errors.health_info?.medical_conditions[index].symptoms.message}</Text>}

            <Controller
              control={control}
              name={`health_info.medical_conditions[${index}].diagnosis_date`}
              render={({ field: { onChange, value } }) => (
                <>
            <TouchableOpacity style={styles.buttonDate} onPress={() => setShowDatePicker(true)}>
            <FontAwesome5 name="calendar-alt" size={20} color="gray" style={styles.iconoCalendario} />
              <Text style={styles.DateText}>
                {value ? new Date(value).toLocaleDateString('en-GB') : "Fecha de diagnostico"}
              </Text>
            </TouchableOpacity>

            {showDatePicker && (
              <DateTimePicker
                testID="dateTimePicker"
                value={value ? new Date(value) : new Date()}
                mode="date"
                display="default"
                onChange={(event, selectedDate) => {
                  setShowDatePicker(false);
                  onChange(selectedDate ? selectedDate.toISOString() : "");
                }}
              />
            )}
          </>
              )}
              rules={{ required: 'Este campo es requerido' }}
              defaultValue=""
            />
            {errors.health_info?.medical_conditions?.[index]?.diagnosis_date && <Text style={{ color: 'red' }}>{errors.health_info?.medical_conditions?.[index]?.diagnosis_date .message}</Text>}

            <TouchableOpacity style={styles.removeButton} onPress={() => removeCondition(index)}>
              <Icon name="delete" size={30} color="#A60010" />
            </TouchableOpacity>
          </View>
        ))}
        <TouchableOpacity style={styles.buttonAñadir} onPress={() => appendCondition({ name: '', severity: '', treatment: '', symptoms: '', diagnosis_date: '' })}>
          <Text style={styles.buttonText}>Añadir Condición</Text>
        </TouchableOpacity>
        
        {/* Hospital Section */}
        <Text style={styles.subtitle}>Hospitales</Text>
        {hospitalFields.map((item, index) => (
          <View key={item.id} style={styles.sectionContainer}>
            <Controller
              control={control}
              name={`hospitals[${index}].name`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Nombre del Hospital"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.hospitals?.[index]?.name && <Text style={styles.error}>{errors.hospitals[index].name.message}</Text>}
            
            <Controller
              control={control}
              name={`hospitals[${index}].phone`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Teléfono"
                  keyboardType='numeric'
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
            )}
            rules={{
              required: 'Este campo es requerido',
              pattern: { value: /^\d{3}-\d{3}-\d{4}$/, message: 'Ingrese un número de teléfono válido (###-###-####)' },
            }}
            defaultValue=""
          />
          {errors.hospitals?.[index]?.phone && <Text style={styles.error}>{errors.hospitals?.[index]?.phone.message}</Text>}

            <Controller
              control={control}
              name={`hospitals[${index}].street`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Calle"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.hospitals?.[index]?.street && <Text style={styles.error}>{errors.hospitals[index].street.message}</Text>}
            
            <Controller
              control={control}
              name={`hospitals[${index}].city`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Ciudad"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.hospitals?.[index]?.city && <Text style={styles.error}>{errors.hospitals[index].city.message}</Text>}
            
            <Controller
              control={control}
              name={`hospitals[${index}].state`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Estado"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.hospitals?.[index]?.state && <Text style={styles.error}>{errors.hospitals[index].state.message}</Text>}
            
            <Controller
              control={control}
              name={`hospitals[${index}].zip`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Código Postal"
                  keyboardType='numeric'
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.hospitals?.[index]?.zip && <Text style={styles.error}>{errors.hospitals[index].zip.message}</Text>}
            
            <TouchableOpacity style={styles.removeButton} onPress={() => removeHospital(index)}>
              <Icon name="delete" size={30} color="#A60010" />
            </TouchableOpacity>
          </View>
        ))}
        <TouchableOpacity style={styles.buttonAñadir} onPress={() => appendHospital({ name: '', phone: '', street: '', city: '', state: '', zip: '' })}>
          <Text style={styles.buttonText}>Añadir Hospital</Text>
        </TouchableOpacity>
         
        {/* Documentation Section */}
        <Text style={styles.subtitle}>Documentos Médicos</Text>
{documents.map((document, index) => (
  <View key={index} style={styles.documentContainer}>
     <Text style={styles.documentText}>{document.name}</Text>
    <TouchableOpacity style={styles.removeButton} onPress={() => removeDocument(index)}>
      <Icon name="delete" size={30} color="#A60010" />
    </TouchableOpacity>
  </View>
))}
<TouchableOpacity style={styles.buttonAñadir} onPress={pickDocument}>
  <Text style={styles.buttonText}>Añadir Documento</Text>
</TouchableOpacity>

        {/* Botón para enviar el formulario */}
        <TouchableOpacity style={styles.button} onPress={handleSubmit(onSubmit)}>
          <Text style={styles.buttonText}>Siguiente</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};
 

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 15,
    color: '#333333',
    marginBottom: 20,
  },
  subtitle: {
    fontSize: 15,
    color: '#333333',
    marginBottom: 10,
  },
  dropdownContainer: {
    borderWidth: 1,
    borderColor: '#D2D2DA',
    borderRadius: 5,
    marginBottom: 5,
    width: '15%', // Ajusta el ancho según sea necesario
    alignSelf: 'center', // Centrar el dropdown dentro de su contenedor
  },
  dropdownSelect: {
    padding: 5, // Reducir el padding
    backgroundColor: '#f0f0f0', // Color de fondo para el área de selección
    color: '#333', // Color del texto para el área de selección
    fontSize: 14, // Reducir el tamaño de la fuente si es necesario
  },
  dropdownOptionText: {
    padding: 5, // Reducir el padding
    color: '#555', // Color del texto para las opciones
    fontSize: 14, // Reducir el tamaño de la fuente si es necesario
  },
  dropdown: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    backgroundColor: '#fff', // Color de fondo para el menú desplegable
  },
  input: {
    height: 40,
    borderColor: '#D2D2DA',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
    borderRadius: 8,
  },
  error: {
    color: 'red',
  },
  iconoCalendario: {
    marginRight: 10
  },
  button: {
    backgroundColor: '#007163',
    padding: 10,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonAñadir: {
    backgroundColor: '#00A696',
    padding: 10,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
  },
  buttonDate: {
    flexDirection: 'row',  
    borderColor: '#D2D2DA',
    backgroundColor: "#FFFFFF", // Fondo blanco
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
    borderWidth: 1, // Define el ancho del borde para que sea visible
    marginBottom: 5,
    alignItems: 'center',
  },
  DateText: {
    color: 'gray',
    fontSize: 15,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
  },
  documentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    marginBottom: 10,
  },
  documentText: {
    fontSize: 16,
    color: '#333',
  },
  sectionContainer: {
    borderWidth: 1,
    borderColor: '#D2D2DA',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    backgroundColor: '#ffffff',
    shadowColor: '#333333',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 5,
  },
  removeButton: {
    alignSelf: 'flex-end',
  },
  uploadButtonText: {
    color: '',
    fontSize: 16,
  },
});

export default MedicalInfo;
