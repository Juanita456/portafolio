// HomeScreen.js

import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';
import * as SecureStore from 'expo-secure-store';

const KEY_ON_STORAGE = "KEY_ON_STORAGE";

const PatientScreen = ({ navigation }) => {
  const [token, setToken] = useState(null);

  useEffect(() => {
    const fetchToken = async () => {
      const storedToken = await SecureStore.getItemAsync(KEY_ON_STORAGE);
      if (!storedToken) {
        navigation.replace('Login');
      } else {
        setToken(storedToken);
      }
    };
    fetchToken();
  }, []);

  const handleLogoutPress = async () => {
    await SecureStore.deleteItemAsync(KEY_ON_STORAGE);
    navigation.replace('Login');
  };

  return (
    <View style={styles.container}>
      <Text>Bienvenido Paciente</Text>
      <Button title="Logout" onPress={handleLogoutPress} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default PatientScreen;
