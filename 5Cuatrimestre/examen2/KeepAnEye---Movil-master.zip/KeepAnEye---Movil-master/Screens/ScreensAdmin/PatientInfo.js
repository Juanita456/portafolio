//importaciones 
import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, TextInput, Alert,Button, ScrollView } from 'react-native';
import { API_URL } from '../../Puerto';
import { useForm, Controller } from 'react-hook-form';
import DateTimePicker from '@react-native-community/datetimepicker';
import DropdownSelect from 'react-native-input-select';
import { FontAwesome5 } from '@expo/vector-icons';

const PersonalInfo = ({ navigation, route }) => {
  //se utilizan para gestionar la validación del formulario y la recopilación de datos cuando se envía el formulario.
  const { control, handleSubmit, formState: { errors } } = useForm();
  const [showDatePicker, setShowDatePicker] = useState(false); // Añadir estado para el DateTimePicker
  const [date, setDate] = useState(new Date());
  const { _id: adminId } = route.params;

  const onSubmit = async (data) => {  
    try {
      const response = await fetch(`${API_URL}/patients/registerPatient`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: {
            first_name: data.first_name,
            last_name: data.last_name,
          },
          sex: data.sex,
          born_date: data.born_date,
          user_type: data.status || 'patient',
          email: data.email,
          password: data.password,
          phone: data.phone,
          address: {
            street: data.street,
            city: data.city,
            state: data.state,
            zip: data.zip,
          },
          status: data.status || 'active', // Provide a default value if status is not available
        }),
      });

      if (!response.ok) {
        throw new Error('No se pudo registrar el paciente.');
      }
  
      const responseData = await response.json();
  
      if (responseData._id) {
        const updateAdminResponse = await fetch(`${API_URL}/UpdateAdmin/${adminId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            patient_id: responseData._id,
            relationship: data.relationship,
          }),
        });
  
        if (!updateAdminResponse.ok) {
          throw new Error('No se pudo actualizar el admin.');
        }
        navigation.navigate('MedicalInfo', { patientId: responseData._id });
      } else {
        throw new Error('ID del paciente no encontrado en la respuesta.');
      }
    } catch (error) {
      Alert.alert('Error', 'No se pudo registrar la información del paciente. Inténtalo de nuevo.');
      console.error(error);
    }
  };
  

  return (
    <View style={styles.container}>
      <ScrollView>
      <Text style={styles.title}>Parentesco:</Text>
    <Controller
          control={control}
          name="relationship"
          render={({ field: { onChange, value } }) => (
            <DropdownSelect
            placeholder="parentesco"
            options={[
              { name: 'Padre', id: 'padre' },
              { name: 'Madre', id: 'madre' },
              { name: 'Hermano(a)', id: 'hermano(a)' },
              { name: 'Tio(a)', id: 'tio(a)' },
              { name: 'Primo(a)', id: 'primo(a)' },
              { name: 'Amigo Cercano', id: 'amigo' },
            ]}
            optionLabel="name"
            optionValue="id"
            selectedValue={value}
            onValueChange={(itemValue) => {
              onChange(itemValue);
            }}
            containerStyle={styles.dropdownContainer}
            selectStyle={styles.dropdownSelect}
            optionTextStyle={styles.dropdownOptionText}
            dropdownStyle={styles.dropdown}
            />
          )}
          rules={{ required: 'Este campo es requerido' }}
          defaultValue=""
        />
        {errors.relationship && <Text style={styles.error}>{errors.relationship.message}</Text>}
        <Text style={styles.title}>Información Personal</Text>
  
        <Controller
          control={control}
          name="first_name"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Nombre"
              value={value}
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{ required: 'Este campo es requerido', pattern: { value: /^[A-Za-z ]+$/, message: 'Ingrese solo letras y espacios' } }}
          defaultValue=""
        />
        {errors.first_name && <Text style={styles.error}>{errors.first_name.message}</Text>}

        <Controller
          control={control}
          name="last_name"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Apellido"
              value={value}
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{ required: 'El apellido es requerido', pattern: { value: /^[A-Za-z ]+$/, message: 'Ingrese solo letras y espacios' } }}
          defaultValue=""
        />
        {errors.last_name && <Text style={styles.error}>{errors.last_name.message}</Text>}
        <View style={styles.dateContainer}>
        <Controller
          control={control}
          name="sex"
          render={({ field: { onChange, value } }) => (
            <DropdownSelect
            placeholder="Sexo"
            options={[
              { name: 'Masculino', id: 'male' },
              { name: 'Femenino', id: 'female' },
            ]}
            optionLabel="name"
            optionValue="id"
            selectedValue={value}
            onValueChange={(itemValue) => {
              onChange(itemValue);
            }}
            containerStyle={styles.dropdownContainer}
            selectStyle={styles.dropdownSelect}
            optionTextStyle={styles.dropdownOptionText}
            dropdownStyle={styles.dropdown}
            />
          )}
          rules={{ required: 'Este campo es requerido' }}
          defaultValue=""
        />
        {errors.sex && <Text style={styles.error}>{errors.sex.message}</Text>}
        <Controller
        control={control}
        name="born_date"
        render={({ field: { onChange, value } }) => (
          <>
            <TouchableOpacity style={styles.buttonDate} onPress={() => setShowDatePicker(true)}>
            <FontAwesome5 name="calendar-alt" size={20} color="gray" style={styles.iconoCalendario} />
              <Text style={styles.DateText}>
                {value ? new Date(value).toLocaleDateString('en-GB') : "Fecha de nacimiento"}
              </Text>
            </TouchableOpacity>

            {showDatePicker && (
              <DateTimePicker
                testID="dateTimePicker"
                value={value ? new Date(value) : new Date()}
                mode="date"
                display="default"
                onChange={(event, selectedDate) => {
                  setShowDatePicker(false);
                  onChange(selectedDate ? selectedDate.toISOString() : "");
                }}
              />
            )}
          </>
        )}
        rules={{ required: 'Este campo es requerido' }}
        defaultValue=""
      />
      {errors.born_date && <Text style={{ color: 'red' }}>{errors.born_date.message}</Text>}
</View>
        <Controller
          control={control}
          name="email"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Correo Electrónico"
              value={value}
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{
            required: 'Este campo es requerido',
            pattern: {
              value: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\.[a-zA-Z]{2,})?/,
              message: 'Ingrese un email válido',
            },
          }}
          defaultValue=""
        />
        {errors.email && <Text style={styles.error}>{errors.email.message}</Text>}

        <Controller
          control={control}
          name="password"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Contraseña"
              value={value}
              secureTextEntry
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{
            required: 'Este campo es requerido',
          }}
          defaultValue=""
        />
        {errors.password && <Text style={styles.error}>{errors.password.message}</Text>}

        <Controller
          control={control}
          name="phone"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Teléfono"
              keyboardType="numeric"
              value={value}
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{
            required: 'Este campo es requerido',
            pattern: { value: /^\d{3}-\d{3}-\d{4}$/, message: 'Ingrese un número de teléfono válido (###-###-####)' },
          }}
          defaultValue=""
        />
        {errors.phone && <Text style={styles.error}>{errors.phone.message}</Text>}

        <Text style={styles.title}>Dirección</Text>

        <Controller
          control={control}
          name="street"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Calle"
              value={value}
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{ required: 'Calle es requerido', pattern: { value: /^[A-Za-z0-9 ]+$/, message: 'Ingrese solo letras, números y espacios' } }}
          defaultValue=""
        />
        {errors.street && <Text style={styles.error}>{errors.street.message}</Text>}

        <Controller
          control={control}
          name="city"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Ciudad"
              value={value}
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{ required: 'Ciudad es requerido', pattern: { value: /^[A-Za-z ]+$/, message: 'Ingrese solo letras y espacios' } }}
          defaultValue=""
        />
        {errors.city && <Text style={styles.error}>{errors.city.message}</Text>}

        <Controller
          control={control}
          name="state"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Estado"
              value={value}
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{ required: 'Estado es requerido', pattern: { value: /^[A-Za-z ]+$/, message: 'Ingrese solo letras y espacios' } }}
          defaultValue=""
        />
        {errors.state && <Text style={styles.error}>{errors.state.message}</Text>}

        <Controller
          control={control}
          name="zip"
          render={({ field: { onChange, value } }) => (
            <TextInput
              placeholder="Código Postal"
              value={value}
              keyboardType="numeric"
              onChangeText={onChange}
              style={styles.input}
            />
          )}
          rules={{ required: 'Código Postal es requerido', pattern: { value: /^[0-9]+$/, message: 'Ingrese solo números' } }}
          defaultValue=""
        />
        {errors.zip && <Text style={styles.error}>{errors.zip.message}</Text>}

        <TouchableOpacity style={styles.button} onPress={handleSubmit(onSubmit)}>
          <Text style={styles.buttonText}>Siguiente</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 15,
    color: '#333333',
  },
  input: {
    height: 40,
    borderColor: '#D2D2DA',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
    borderRadius: 8,
  },
  dateContainer: {
    width: '48%', // Ajusta el ancho según sea necesario
    flexDirection: 'row',
    justifyContent: 'space-between',

  },
  error: {
    color: 'red',
    marginBottom: 5,
  },
  dropdownContainer: {
    borderWidth: 1,
    borderColor: '#D2D2DA',
    borderRadius: 5,
    marginBottom: 10,
    width: '45%',
    alignSelf: 'center', // Centrar el dropdown dentro de su contenedor
    marginRight: 10,
  },
  dropdownSelect: {
    padding: 5, // Reducir el padding
    backgroundColor: '#f0f0f0', // Color de fondo para el área de selección
    color: '#333', // Color del texto para el área de selección
    fontSize: 14, // Reducir el tamaño de la fuente si es necesario
  },
  dropdownOptionText: {
    padding: 5, // Reducir el padding
    color: '#555', // Color del texto para las opciones
    fontSize: 14, // Reducir el tamaño de la fuente si es necesario
  },
  dropdown: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    backgroundColor: '#fff', // Color de fondo para el menú desplegable
  },
  iconoCalendario: {
    marginRight: 10
  },
  button: {
    backgroundColor: '#007163',
    padding: 10,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonDate: {
    flexDirection: 'row',  
    borderColor: '#D2D2DA',
    backgroundColor: "#FFFFFF", // Fondo blanco
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
    borderWidth: 1, // Define el ancho del borde para que sea visible
    marginBottom: 5,
    alignItems: 'center',
    width: '100%',
height:'75%',
marginLeft: 10,
  },
  DateText: {
    color: 'gray',
    fontSize: 15,
  },
  
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
  }
});

export default PersonalInfo;
