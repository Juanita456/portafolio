import React from 'react';
import { StyleSheet, Text, View, TextInput, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { API_URL } from '../../Puerto';
import { useForm, Controller, useFieldArray } from 'react-hook-form';
import Icon from 'react-native-vector-icons/MaterialIcons';

const EmergencyContact = ({ navigation, route }) => {
  const { control, handleSubmit, formState: { errors } } = useForm({
    defaultValues: {
      emergencyContacts: [{ name: '', relationship: '', contactInformation: { phone: '', email: '' } }],
    },
  });

  const patientId = route.params?.patientId;

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'emergencyContacts',
  });

  const onSubmit = async (data) => {
    try {
      // Submit Emergency Contact Info
      const contactResponse = await fetch(`${API_URL}/patients/registerContact`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          patient_id: patientId, // Enviar el ID del paciente
          emergency_contacts: data.emergencyContacts.map(contact => ({
            name: contact.name,
            relationship: contact.relationship,
            contactInformation: {
              phone: contact.contactInformation.phone,
              email: contact.contactInformation.email,
            },
            notifications: [
              { type: 'default_type_value', status: 'default_status_value' } // Valores predeterminados para notificaciones
            ],
          })),
        }),
      });

      if (!contactResponse.ok) {
        throw new Error('No se pudo guardar la información de contacto de emergencia.');
      }

      // Mostrar mensaje de éxito
      Alert.alert('Éxito', 'Se han guardado los contactos de emergencia correctamente.', [
        {
          text: 'OK',
          onPress: () => {
            // Navegar de regreso a la pantalla de inicio (HomeScreen)
            navigation.navigate('Registro Pacientes');
          },
        },
      ]);
    } catch (error) {
      console.error('Error submitting form:', error);
      // Mostrar mensaje de error
      Alert.alert('Error', 'Hubo un problema al guardar los contactos de emergencia. Por favor, inténtalo de nuevo más tarde.');
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView>
        <Text style={styles.title}>Información de Contactos de Emergencia</Text>
        {fields.map((item, index) => (
          <View key={item.id} style={styles.contactContainer}>
            <Controller
              control={control}
              name={`emergencyContacts[${index}].name`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Nombre"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.emergencyContacts?.[index]?.name && <Text style={styles.error}>{errors.emergencyContacts[index].name.message}</Text>}

            <Controller
              control={control}
              name={`emergencyContacts[${index}].relationship`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Parentesco"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido" }}
              defaultValue=""
            />
            {errors.emergencyContacts?.[index]?.relationship && <Text style={styles.error}>{errors.emergencyContacts[index].relationship.message}</Text>}

            <Controller
              control={control}
              name={`emergencyContacts[${index}].contactInformation.email`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Correo Electrónico"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido", pattern: { value: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\.[a-zA-Z]{2,})?/, message: "Ingrese un email válido" } }}
              defaultValue=""
            />
            {errors.emergencyContacts?.[index]?.contactInformation?.email && <Text style={styles.error}>{errors.emergencyContacts[index].contactInformation.email.message}</Text>}

            <Controller
              control={control}
              name={`emergencyContacts[${index}].contactInformation.phone`}
              render={({ field: { onChange, value } }) => (
                <TextInput
                  placeholder="Teléfono"
                  keyboardType="numeric"
                  value={value}
                  onChangeText={onChange}
                  style={styles.input}
                />
              )}
              rules={{ required: "Este campo es requerido", pattern: { value: /\d{3}-\d{3}-\d{4}/, message: "Ingrese un número de teléfono válido (ej. 664-999-9999)" } }}
              defaultValue=""
            />
            {errors.emergencyContacts?.[index]?.contactInformation?.phone && <Text style={styles.error}>{errors.emergencyContacts[index].contactInformation.phone.message}</Text>}

            <TouchableOpacity style={styles.removeButton} onPress={() => remove(index)}>
              <Icon name="delete" size={30} color="#A60010" />
            </TouchableOpacity>
          </View>
        ))}
        <TouchableOpacity style={styles.button} onPress={() => append({ name: '', relationship: '', contactInformation: { phone: '', email: '' } })}>
          <Text style={styles.buttonText}>Añadir Contacto</Text>
        </TouchableOpacity>
        {/* <TouchableOpacity style={styles.button} onPress={() => navigation.goBack()}>
          <Text style={styles.buttonText}>Anterior</Text>
        </TouchableOpacity> */}
        <TouchableOpacity style={styles.button} onPress={handleSubmit(onSubmit)}>
          <Text style={styles.buttonText}>Guardar</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 15,
    color: '#333333',
    marginBottom: 20,
  },
  contactContainer: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    backgroundColor: '#ffffff',
    shadowColor: '#333333',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 5,
  },
  input: {
    height: 40,
    borderColor: '#D2D2DA',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
    borderRadius: 8,
  },
  error: {
    color: 'red',
    marginBottom: 10,
  },
  removeButton: {
    alignSelf: 'flex-end',
  },
  buttonAñadir: {
    backgroundColor: '#00A696',
    padding: 10,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#007163',
    padding: 10,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
  },
});

export default EmergencyContact;
