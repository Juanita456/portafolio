/** @format */

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import { Ionicons } from '@expo/vector-icons';
import { StyleSheet } from 'react-native';

import UserTypeScreen from './Screens/UserTypeScreen';
import LoginScreen from './Screens/LoginScreen';
import HomeScreen from './Screens/HomeScreen';
import PatientScreen from './Screens/PatientScreen';
import PatientProfile from './Screens/ScreensAdmin/PatientProfile';
import PatientRegistration from './Screens/ScreensAdmin/PatientRegistration';

import PatientInfo from './Screens/ScreensAdmin/PatientInfo';
import MedicalInfo from './Screens/ScreensAdmin/MedicalInfo';
import EmergencyContact from './Screens/ScreensAdmin/EmergencyContact';

const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
        <Stack.Screen name="Drawer" component={DrawerNavigator} options={{ headerShown: false }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const DrawerNavigator = ({ route }) => {
  const { user_type} = route.params || {};
  const { _id } = route.params;

  if (!user_type) {
    return (
      <View style={styles.container}>
        <Text>Tipo de usuario no encontrado</Text>
      </View>
    );
  }

  return (
    <Drawer.Navigator
      screenOptions={{
          drawerStyle: styles.drawer,
          drawerActiveTintColor: '#00A696',
          drawerInactiveTintColor: '#333333',
          headerStyle: {
            backgroundColor: '#007C71',
          },
          headerTintColor: '#E9E9F2',
          drawerContentStyle: {
            // Estilos para el contenido del drawer
            backgroundColor: '#D2D2DA',
            color: '', // Color del ícono del drawer (blanco)
          },
      }}
    >
      {user_type === 'admin' ? (
        <>
          <Drawer.Screen
            name="Inicio"
            component={HomeScreen}
            options={{
              drawerIcon: ({ color, size }) => (
                <Ionicons name="home" size={size} color={color} />
              ),
            }}
            initialParams={{ _id }}
          />
          <Drawer.Screen
            name="Perfil de los pacientes"
            component={PatientProfile}
            options={{
              drawerIcon: ({ color, size }) => (
                <Ionicons name="person" size={size} color={color} />
              ),
            }}
            initialParams={{ _id}}
          />
          <Drawer.Screen
            name="Registro de pacientes"
            component={PatientRegistration}
            options={{
              drawerIcon: ({ color, size }) => (
                <Ionicons name="person-add" size={size} color={color} />
              ),
            }}
            initialParams={{ _id}}
          />
        </>
      ) : (
        <>
          <Drawer.Screen
            name="Patient"
            component={PatientScreen}
            options={{
              drawerIcon: ({ color, size }) => (
                <Ionicons name="medkit" size={size} color={color} />
              ),
            }}
            initialParams={{ _id}}
          />
        </>
      )}
    </Drawer.Navigator>
  );
};

const styles = StyleSheet.create({
  drawer: {
    backgroundColor: '#D2D2DA',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default App;
