import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const UserTypeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Eres Cuidador o Paciente?</Text>
      <View style={styles.buttonContainer}>
        <Button
          title="Cuidador"
          onPress={() => navigation.navigate('Login', { user_type: 'admin' })}
          color="#007C71"
        />
      </View>
      <View style={styles.buttonContainer}>
        <Button
          title="Paciente"
          onPress={() => navigation.navigate('Login', { user_type: 'patient' })}
          color="#00A696"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 22,
    marginBottom: 20,
    color: '#333333',
  },
  buttonContainer: {
    marginVertical: 10,
    width: '70%',
  },
});

export default UserTypeScreen;

