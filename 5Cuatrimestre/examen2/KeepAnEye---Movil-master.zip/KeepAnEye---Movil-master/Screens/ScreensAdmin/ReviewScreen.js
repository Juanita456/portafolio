import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';

const ReviewScreen = ({ navigation, route }) => {
  const { PatientInfo, EmergencyContact, MedicalInfo } = route.params;

  const handleSubmit = async () => {
    try {
      // Submit Patient Info
      const patientResponse = await fetch('http://192.168.1.114:9000/patients/registerPatient', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: {
            first_name: PatientInfo.first_name,
            last_name: PatientInfo.last_name,
          },
          sex: PatientInfo.sex,
          born_date: PatientInfo.born_date,
          user_type: PatientInfo.user_type,
          email: PatientInfo.email,
          password: PatientInfo.password,
          phone: PatientInfo.phone,
          address: {
            street: PatientInfo.street,
            city: PatientInfo.city,
            state: PatientInfo.state,
            zip: PatientInfo.zip,
          },
          status: PatientInfo.status || 'active', // Provide a default value if status is not available
        }),
      });

      const patientText = await patientResponse.text();
      console.log('Patient response text:', patientText);
      const patientResult = JSON.parse(patientText);
      console.log('Patient info saved:', patientResult);

      // Assuming patient_id is the _id returned from the saved patient
      const patient_id = patientResult._id;

        // Submit Medical Info
        const medicalResponse = await fetch('http://192.168.1.114:9000/patients/registerMedicalInfo', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            patient_id: patient_id, // Link to the patient
            NSS: MedicalInfo.NSS,
            blood_type: MedicalInfo.blood_type,
            height: MedicalInfo.height,
            weight: MedicalInfo.weight,
            health_info: {
              medicines: MedicalInfo.medicines.map(medicine => ({
                name: medicine.name,
                dosage: medicine.dosage,
                frequency: medicine.frequency,
              })),
              allergies: MedicalInfo.allergies.map(allergy => ({
                name: allergy.name,
                severity: allergy.severity,
                reaction: allergy.reaction,
                treatment: allergy.treatment,
              })),
              medical_conditions: MedicalInfo.medical_conditions.map(condition => ({
                name: condition.name,
                severity: condition.severity,
                treatment: condition.treatment,
                symptoms: condition.symptoms,
                diagnosis_date: condition.diagnosis_date,
              })),
            },
            hospitals: MedicalInfo.hospitals.map(hospital => ({
              name: hospital.name,
              phone: hospital.phone,
              address: {
                street: hospital.street,
                city: hospital.city,
                state: hospital.state,
                zip: hospital.zip,
              },
            })),
            medical_documents: MedicalInfo.medical_documents.map(document => ({
              name: document.name,
              type: document.type,
              date: document.date,
              url: document.url,
            })),
          }),
        });
  
        const medicalText = await medicalResponse.text();
        console.log('Medical response text:', medicalText);
        const medicalResult = JSON.parse(medicalText);
        console.log('Medical info saved:', medicalResult);

      // Submit Emergency Contact Info
      const contactResponse = await fetch('http://192.168.1.114:9000/patients/registerContact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          patient_id: patient_id, // Link to the patient
          emergency_contacts: EmergencyContact.emergency_contacts.map(contact => ({
            name: contact.name,
            relationship: contact.relationship,
            contactInformation: {
              phone: contact.contactInformation.phone,
              email: contact.contactInformation.email,
            },
            notifications: [
              { type: 'default_type_value', status: 'default_status_value' } // Valores predeterminados
            ],
          })),
        }),
      });

      const contactText = await contactResponse.text();
      console.log('Contact response text:', contactText);
      const contactResult = JSON.parse(contactText);
      console.log('Emergency contact info saved:', contactResult);

      // Handle success, e.g., navigate to a confirmation screen
    } catch (error) {
      console.error('Error submitting form:', error);
      // Handle error, e.g., show an error message
    }
  };

  return (
    <View style={styles.container}>
      <Text>Revisión de Información</Text>
      <Text>{JSON.stringify(PatientInfo, null, 2)}</Text>
      <Text>{JSON.stringify(MedicalInfo, null, 2)}</Text>
      <Text>{JSON.stringify(EmergencyContact, null, 2)}</Text>
      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Confirm</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  button: {
    backgroundColor: '#00A696',
    padding: 10,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
  },
});

export default ReviewScreen;
